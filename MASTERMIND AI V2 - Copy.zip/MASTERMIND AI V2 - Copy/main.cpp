#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// version 2 Find the position of the first digit
string mastermindAI(int correct, int incorrect) {
    static int currentDigit = 0; // Initialize the current digit to 0
    static int currentPosition = 0;
    static vector<int> digitsFound; // Initialize a vector to store the digits found
    static bool findDigits = true; // Flag to track if we need to find digits

  // if findDigits is true, we need to find digits
    if (findDigits) {
        if (correct > 0) {
            digitsFound.push_back(currentDigit); // Add the current digit to the vector
        }
        if (currentDigit < 9) {
            currentDigit++;
            return string(4, '0' + currentDigit);
          // else we need to find positions
        } else { 
            findDigits = false;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
          // 
        }
    } else // if findDigits is false, we need to find positions
    {
        if (currentPosition < 4) 
        {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[0]; // Set the current position to the first digit found
            currentPosition++; // Increment the current position
            return guess;
        }
    }
    return "0000"; // Default return, should never reach here
}

int main() {
    int correct, incorrect; 
    string guess;

    while (true) {
        cout << "Enter the number of correct positions: ";
        cin >> correct;
        cout << "Enter the number of incorrect positions: ";
        cin >> incorrect;
        guess = mastermindAI(correct, incorrect); // Call the mastermindAI function
        cout << "AI's next guess: " << guess << endl;
        if (correct == 4) {
            cout << "AI has guessed the code!" << endl;
            break;
        }
    }

    return 0;
}
