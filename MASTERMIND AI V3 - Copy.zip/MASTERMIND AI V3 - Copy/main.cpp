#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

//ersion 3 Find the position of the second digit


string mastermindAI(int correct, int incorrect) {
    static int currentDigit = 0; 
    static int currentPosition = 0;
    static vector<int> digitsFound;
    static enum { FIND_DIGITS, FIND_POSITION_FIRST, FIND_POSITION_SECOND } state = FIND_DIGITS;

    if (state == FIND_DIGITS) // Find the digits
    {
        if (correct > 0) {
            digitsFound.push_back(currentDigit); // Add the digit to the list of found digits
        }
        if (currentDigit < 9) {
            currentDigit++; // incrment the digit
            return string(4, '0' + currentDigit);
        } else // If the digit is 9, reset it to 0 and move on to the next position
        {
            state = FIND_POSITION_FIRST;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_FIRST) //
    {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[0]; // Set the first digit to the first found digit
            currentPosition++;
            return guess;
        } else // If the position is 4, reset it to 0 and move on to the second position
        {
            state = FIND_POSITION_SECOND;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_SECOND) // means
    {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[1]; // Set the second digit to the second found digit
            currentPosition++;
            return guess;
        }
    }
    return "0000"; // Default return, should never reach here
}

int main() {
    int correct, incorrect;
    string guess;

    while (true) {
        cout << "Enter the number of correct positions: ";
        cin >> correct;
        cout << "Enter the number of incorrect positions: ";
        cin >> incorrect;
        guess = mastermindAI(correct, incorrect);
        cout << "AI's next guess: " << guess << endl;
        if (correct == 4) {
            cout << "AI has guessed the code!" << endl;
            break;
        }
    }

    return 0;
}
