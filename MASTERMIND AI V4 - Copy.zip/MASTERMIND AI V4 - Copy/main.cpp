#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

//Version #4 Find the position of the third digit


string mastermindAI(int correct, int incorrect) {
    static int currentDigit = 0;
    static int currentPosition = 0;
    static vector<int> digitsFound;
    static enum { FIND_DIGITS, FIND_POSITION_FIRST, FIND_POSITION_SECOND, FIND_POSITION_THIRD } state = FIND_DIGITS; // Initialize the state to FIND_DIGITS

    if (state == FIND_DIGITS) // Find the digits
    {
        if (correct > 0) // If there are correct digits
        {
            digitsFound.push_back(currentDigit); // Add the digit to the vector
        }
        if (currentDigit < 9) {
            currentDigit++; // increment current digit
            return string(4, '0' + currentDigit); // return current as a string
        } else {
            state = FIND_POSITION_FIRST;
            currentPosition = 0;
            return mastermindAI(correct, incorrect); // return ai guess for the first position
        }
    } else if (state == FIND_POSITION_FIRST) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[0]; // Set the first digit to the first digit found
            currentPosition++;
            return guess;
        } else {
            state = FIND_POSITION_SECOND;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_SECOND) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[1]; // Set the second digit to the second digit found
            currentPosition++; // Increment the current position
            return guess;
        } else {
            state = FIND_POSITION_THIRD;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_THIRD) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[2];
            currentPosition++;
            return guess;
        }
    }
    return "0000"; // Default return, should never reach here
}

int main() {
    int correct, incorrect;
    string guess;

    while (true) {
        cout << "Enter the number of correct positions: ";
        cin >> correct;
        cout << "Enter the number of incorrect positions: ";
        cin >> incorrect;
        guess = mastermindAI(correct, incorrect);
        cout << "AI's next guess: " << guess << endl;
        if (correct == 4) {
            cout << "AI has guessed the code!" << endl;
            break;
        }
    }

    return 0;
}
