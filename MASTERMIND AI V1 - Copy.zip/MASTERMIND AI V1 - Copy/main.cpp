#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// version 1 Find the digits
string mastermindAI(int correct, int incorrect) {
    static int currentDigit = 0;
    static vector<int> digitsFound;

    if (correct > 0) {
        digitsFound.push_back(currentDigit); // add the digit to the list of digits found
    }
    if (currentDigit < 9) {
        currentDigit++;
        return string(4, '0' + currentDigit);
    } else {
        return "9999"; //all digits checked
    }
}

int main() {
    int correct, incorrect;
    string guess;

    while (true) {
        cout << "Enter the number of correct positions: ";
        cin >> correct;
        cout << "Enter the number of incorrect positions: ";
        cin >> incorrect;
      //
        guess = mastermindAI(correct, incorrect);
        cout << "AI's next guess: " << guess << endl; // print guess
        if (correct == 4) {
            cout << "AI has guessed the code!" << endl;
            break;
        }
    }

    return 0;
}
