CREATE DATABASE  IF NOT EXISTS `book` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `book`;
-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: book
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `entity_author`
--

DROP TABLE IF EXISTS `entity_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entity_author` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `birth_date` date DEFAULT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_author`
--

LOCK TABLES `entity_author` WRITE;
/*!40000 ALTER TABLE `entity_author` DISABLE KEYS */;
INSERT INTO `entity_author` VALUES (1,'J.K.','Rowling','1965-07-31'),(2,'James','Stewart','1941-03-29'),(3,'John','Doe','1975-01-01'),(4,'Jane','Smith','1980-02-02'),(5,'Albert','Einstein','1879-03-14'),(6,'Isaac','Newton','1643-01-04');
/*!40000 ALTER TABLE `entity_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_book`
--

DROP TABLE IF EXISTS `entity_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entity_book` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `isbn` varchar(20) NOT NULL,
  `publish_year` int(11) DEFAULT NULL,
  `pages` int(11) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  UNIQUE KEY `isbn` (`isbn`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_book`
--

LOCK TABLES `entity_book` WRITE;
/*!40000 ALTER TABLE `entity_book` DISABLE KEYS */;
INSERT INTO `entity_book` VALUES (1,'Harry Potter and the Philosopher\'s Stone','9780747532699',1997,223,'English'),(2,'Calculus','9780538497817',2010,1392,'English'),(3,'Physics for Scientists and Engineers','9780321842077',2013,1600,'English'),(4,'Biology','9780134093413',2016,1488,'English'),(5,'World History','9780133828191',2014,1040,'English'),(6,'Chemistry: The Central Science','9780321910417',2014,1248,'English');
/*!40000 ALTER TABLE `entity_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_publisher`
--

DROP TABLE IF EXISTS `entity_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entity_publisher` (
  `publisher_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`publisher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_publisher`
--

LOCK TABLES `entity_publisher` WRITE;
/*!40000 ALTER TABLE `entity_publisher` DISABLE KEYS */;
INSERT INTO `entity_publisher` VALUES (1,'Bloomsbury','50 Bedford Square','London','UK'),(2,'Cengage Learning','200 First Stamford Place','Stamford','USA'),(3,'Springer','Tiergartenstraße 17','Berlin','Germany'),(4,'Oxford University Press','Great Clarendon Street','Oxford','UK');
/*!40000 ALTER TABLE `entity_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enum_subject`
--

DROP TABLE IF EXISTS `enum_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enum_subject` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(100) NOT NULL,
  PRIMARY KEY (`subject_id`),
  UNIQUE KEY `subject_name` (`subject_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enum_subject`
--

LOCK TABLES `enum_subject` WRITE;
/*!40000 ALTER TABLE `enum_subject` DISABLE KEYS */;
INSERT INTO `enum_subject` VALUES (5,'Biography'),(2,'Fantasy'),(8,'History'),(6,'Mathematics'),(3,'Mystery'),(4,'Non-fiction'),(7,'Science'),(1,'Science Fiction');
/*!40000 ALTER TABLE `enum_subject` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xref_book_author`
--

DROP TABLE IF EXISTS `xref_book_author`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xref_book_author` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`book_id`,`author_id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `xref_book_author_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `entity_book` (`book_id`) ON DELETE CASCADE,
  CONSTRAINT `xref_book_author_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `entity_author` (`author_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xref_book_author`
--

LOCK TABLES `xref_book_author` WRITE;
/*!40000 ALTER TABLE `xref_book_author` DISABLE KEYS */;
INSERT INTO `xref_book_author` VALUES (1,1),(2,2),(3,3),(4,4),(5,5),(6,6);
/*!40000 ALTER TABLE `xref_book_author` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xref_book_publisher`
--

DROP TABLE IF EXISTS `xref_book_publisher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xref_book_publisher` (
  `book_id` int(11) NOT NULL,
  `publisher_id` int(11) NOT NULL,
  PRIMARY KEY (`book_id`,`publisher_id`),
  KEY `publisher_id` (`publisher_id`),
  CONSTRAINT `xref_book_publisher_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `entity_book` (`book_id`) ON DELETE CASCADE,
  CONSTRAINT `xref_book_publisher_ibfk_2` FOREIGN KEY (`publisher_id`) REFERENCES `entity_publisher` (`publisher_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xref_book_publisher`
--

LOCK TABLES `xref_book_publisher` WRITE;
/*!40000 ALTER TABLE `xref_book_publisher` DISABLE KEYS */;
INSERT INTO `xref_book_publisher` VALUES (1,1),(2,2),(3,3),(4,3),(5,4),(6,4);
/*!40000 ALTER TABLE `xref_book_publisher` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xref_book_subject`
--

DROP TABLE IF EXISTS `xref_book_subject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `xref_book_subject` (
  `book_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`book_id`,`subject_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `xref_book_subject_ibfk_1` FOREIGN KEY (`book_id`) REFERENCES `entity_book` (`book_id`) ON DELETE CASCADE,
  CONSTRAINT `xref_book_subject_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `enum_subject` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xref_book_subject`
--

LOCK TABLES `xref_book_subject` WRITE;
/*!40000 ALTER TABLE `xref_book_subject` DISABLE KEYS */;
INSERT INTO `xref_book_subject` VALUES (1,2),(2,6),(3,7),(4,7),(5,8),(6,7);
/*!40000 ALTER TABLE `xref_book_subject` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-28 23:13:56
