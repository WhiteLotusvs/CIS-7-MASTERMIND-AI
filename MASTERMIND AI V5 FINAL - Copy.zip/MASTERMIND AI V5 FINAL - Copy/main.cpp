#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

//final version5: Combined all steps. ("Output the final guess which should be no more than 16 total.")

string mastermindAI(int correct, int incorrect) {
    static int currentDigit = 0;
    static int currentPosition = 0;
    static vector<int> digitsFound;
    static enum { FIND_DIGITS, FIND_POSITION_FIRST, FIND_POSITION_SECOND, FIND_POSITION_THIRD, FIND_POSITION_FOURTH } state = FIND_DIGITS; // Initialize the state to FIND_DIGITS

    if (state == FIND_DIGITS) {
        if (correct > 0) {
            digitsFound.push_back(currentDigit); // Store the digit found
        }
        if (currentDigit < 9) {
            currentDigit++; // Increment the current digit
            return string(4, '0' + currentDigit);
        } else // If all digits have been found, move to the next state
        {
            state = FIND_POSITION_FIRST;
            currentPosition = 0;
            return mastermindAI(correct, incorrect); // Recursively call the function with the updated state
        }
    } else if (state == FIND_POSITION_FIRST) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[0]; // Set the first digit to the first digit found
            currentPosition++;
            return guess; 
        } else {
            state = FIND_POSITION_SECOND;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_SECOND) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[1]; // Set the second digit to the second digit found
            currentPosition++; // after incremeneting the position
            return guess;
        } else {
            state = FIND_POSITION_THIRD;
            currentPosition = 0;
            return mastermindAI(correct, incorrect); // call function with updated state
        }
    } else if (state == FIND_POSITION_THIRD) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[2]; // Set the third digit to the third digit found
            currentPosition++;
            return guess;
        } else // If all digits have been found, move to the next state
        {
            state = FIND_POSITION_FOURTH;
            currentPosition = 0;
            return mastermindAI(correct, incorrect);
        }
    } else if (state == FIND_POSITION_FOURTH) {
        if (currentPosition < 4) {
            string guess(4, '0');
            guess[currentPosition] = '0' + digitsFound[3]; // Set the fourth digit to the fourth digit found
            currentPosition++;
            return guess;
        }
    }
    return "0000"; // Default return, should never reach here
}

int main() {
    int correct, incorrect; // Initialize the variables to store the correct and incorrect guesses
    string guess;

    while (true) {
        cout << "Enter the number of correct positions: ";
        cin >> correct;
        cout << "Enter the number of incorrect positions: ";
        cin >> incorrect;
        guess = mastermindAI(correct, incorrect);
        cout << "AI's next guess: " << guess << endl;
        if (correct == 4) {
            cout << "AI has guessed the code!" << endl;
            break;
        }
    }

    return 0;
}
